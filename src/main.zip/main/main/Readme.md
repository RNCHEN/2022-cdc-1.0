Beginning at `fire.html`

history introduction at `index_start.html`

End at `star.html`

index.html is a temporary file